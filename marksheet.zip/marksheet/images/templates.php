<html>
    <head>
        <title>Student record</title>
        <link href="css/bootstrap.css" type="stylesheet"/>
    </head>
    <body>
        <h1>Student Marksheet System "SMS"</h1>

    </body>
    </html>